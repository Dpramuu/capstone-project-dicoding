// CSS imports
import '../styles/styles.css';
import '../styles/chatbot.css';

import App from './app/app.js';
import Navbar from './components/navbar.js';
import Router from './app/router.js';
import { initChatbot } from "./pages/chatbot/chatbot.js";
import { initSkillFloatingWidget } from "./components/skillFloatingWidget.js";
import "./components/skillFloatingWidget.css";

document.addEventListener('DOMContentLoaded', async () => {
  const app = new App({
    navigationDrawer: document.getElementById("navigation-drawer"),
    drawerButton: document.getElementById("drawer-button"),
    content: document.getElementById("main-content"), // penting!
  });

  // init router
  new Router(app);

   window.addEventListener("hashchange", () => {
    Navbar.load();
  });
  Navbar.load();
});

document.addEventListener("DOMContentLoaded", () => {  // Popup chatbot
  const popup = document.getElementById("learning-buddy-popup");

  setTimeout(() => {
    popup.classList.remove("hidden");
  }, 1000);
});

document.addEventListener("DOMContentLoaded", () => {
  initChatbot(); 
  initSkillFloatingWidget(); 
});




