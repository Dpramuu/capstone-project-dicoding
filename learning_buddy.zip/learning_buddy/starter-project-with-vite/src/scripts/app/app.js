// app/App.js
class App {
  #content;
  #drawerButton;
  #navigationDrawer;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;
    this.#setupDrawer();
  }

  #setupDrawer() {
    this.#drawerButton.addEventListener("click", () => {
      this.#navigationDrawer.classList.toggle("open");
    });

    document.body.addEventListener("click", (event) => {
      const outsideDrawer =
        !this.#navigationDrawer.contains(event.target) &&
        !this.#drawerButton.contains(event.target);

      if (outsideDrawer) {
        this.#navigationDrawer.classList.remove("open");
      }

      this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove("open");
        }
      });
    });
  }

  async renderPage(page) {
    const hash = window.location.hash;
    const queryIndex = hash.indexOf('?');
    const queryString = queryIndex !== -1 ? hash.substring(queryIndex + 1) : '';
    const params = new URLSearchParams(queryString);
    
    console.log("renderPage - hash:", hash, "queryString:", queryString, "params:", params);

    // CASE 1: PAGE BERBASIS CLASS (punya render())
    if (page && typeof page.render === "function") {
      this.#content.innerHTML = await page.render(params);

      if (typeof page.afterRender === "function") {
        await page.afterRender(params);
      }
      return;
    }

    // CASE 2: PAGE BERBASIS FUNCTION
    if (typeof page === "function") {
      this.#content.innerHTML = ""; // clear area
      await page(params); // function bertugas render sendiri
      return;
    }

    console.error("Unknown page format:", page);
    this.renderNotFound();
  }

  renderNotFound() {
    this.#content.innerHTML = `<h2>404 - Page Not Found</h2>`;
  }
}

export default App;
